#### NOTA BENE:  New version of huberM() is only in  'robustbase' !!!
#### --------                   ----------------------------------------
