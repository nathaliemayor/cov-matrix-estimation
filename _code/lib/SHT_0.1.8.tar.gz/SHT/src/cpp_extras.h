#ifndef SHT_SRC_CPP_EXTRAS_H_
#define SHT_SRC_CPP_EXTRAS_H_

double mylog(double val);

#endif
